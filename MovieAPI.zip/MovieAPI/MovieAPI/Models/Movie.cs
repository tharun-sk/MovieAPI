﻿namespace MovieAPI.Models
{
    public class Movie
    {
        public int MovieId { get; set; }

        public string Title { get; set; }
        public string Director { get; set; }
        public string Genre { get; set; }
        public double Rating { get; set; }

        public DateTime ReleaseDate { get; set; }

        public override string ToString()
        {
            return $"Id: {MovieId} Title: {Title} Director:{Director} ,  Genre:{Genre} \n ReleaseDate:{ReleaseDate}";
        }

    }
}
