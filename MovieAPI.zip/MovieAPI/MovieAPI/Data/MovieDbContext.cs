﻿using MovieAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Headers;

namespace MovieAPI.Data
{
    public class MovieDbContext
    {
        //declare the dbset
        public DbSet<Movie> Movies { get; set; }

    }

}
