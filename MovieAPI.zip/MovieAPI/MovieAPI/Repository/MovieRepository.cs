﻿using Microsoft.AspNetCore.Mvc;
using MovieAPI.Models;

namespace MovieAPI.Repository
{
    public class MovieRepository : IMovieRepository
    {   

        //magic line for swagger close
        //MovieRepository movienotfound = new MovieRepository();
        List<Movie> nomovieList = new List<Movie>();

        List<Movie> movieList = new List<Movie>()
        {
            new Movie{MovieId = 1 , Title = "Avengers: Endgame" , Director ="Anthony and Joe Russo" , Rating = 8.4 , Genre ="Action" , ReleaseDate = new DateTime(2019, 4, 26)},
            new Movie{MovieId = 2, Title = "Spider-Man: No Way Home" , Director ="Jon Watts" , Rating = 8.3 , Genre ="Action" , ReleaseDate = new DateTime(2021, 12, 17)},
            new Movie{MovieId = 3 , Title = "The Dark Knight" , Director ="Christopher Nolan" , Rating = 9.0 , Genre ="Action" , ReleaseDate = new DateTime(2008, 7, 18)},
            new Movie{MovieId = 4 , Title = "Wonder Woman" , Director ="Patty Jenkins" , Rating = 7.4 , Genre ="Action" , ReleaseDate = new DateTime(2017, 6, 2)},
            new Movie{MovieId = 5 , Title = "Black Panther" , Director ="Ryan Coogler" , Rating = 7.3 , Genre ="Action" , ReleaseDate = new DateTime(2018, 2, 16)},
        };
        private List<Movie> _movies = new List<Movie>();
        public int CreateMovie(Movie movie)
        {
            throw new NotImplementedException();
        }
        public Movie Add(Movie newMovie)
        {
            newMovie.MovieId = movieList.Count > 0 ? movieList.Max(m => m.MovieId) + 1 : 1; // Assign a new ID
            movieList.Add(newMovie);
            return newMovie;
        }
        //[HttpDelete("{id}")]
        //public ActionResult DeleteMovie(int id)
        //{
        //    var movie = MovieRepository.GetById(id);
        //    if (movie == null)
        //    {
        //        return "Movie not found.";
        //    }

        //    MovieRepository.Delete(id); // Call the repository method to delete the movie.
        //    return NoContent(); // Return 204 No Content on successful delete.
        //}

        public List<Movie> GetAll()
        {
            return movieList;
        }

        public Movie GetById(int id)
        {
            //singleordefault handles when there is no id found whereas single doesn't handle it..!!!!
            return movieList.SingleOrDefault(item => item.MovieId == id);



            //bool exists = movieList.Any(m => m.MovieId == id);

            //if (exists)
            //{
            //    return movieList.Single(item => item.MovieId == id);
            //}
            //else
            //{
            //    MovieRepository movienotfound = new MovieRepository();
            //    Movie nomovie = new Movie();
            //    nomovie.Title = "Movie not found";
            //    nomovieList.Add(nomovie);
            //    //return nomovieList;
            //    return nomovie;
            //}


        }


        public int DeleteMovie(int id)
        {
            Movie movie = GetById(id);
            if (movie != null)
            {
                movieList.Remove(movie);
                return 1;
            }
            return 0;
        }

        public void Update(Movie updatedMovie)
        {
            var movie = movieList.FirstOrDefault(m => m.MovieId == updatedMovie.MovieId);
            if (movie != null)
            {
                movie.Title = updatedMovie.Title;
                movie.Director = updatedMovie.Director;
                movie.ReleaseDate = updatedMovie.ReleaseDate;
                // Update other properties as needed.
            }
        }

        public Movie UpdateMovie(int id, double rating)
        {
            throw new NotImplementedException();
        }
    }
}
