﻿using MovieAPI.Models;

namespace MovieAPI.Repository
{
    public interface IMovieRepository
    {
        List<Movie> GetAll();
        Movie GetById(int id);

        int CreateMovie(Movie movie);

        Movie UpdateMovie(int id, double rating);

        //int DeleteMovie(int id);
        public int DeleteMovie(int id);

        public Movie Add(Movie newMovie);

        public void Update(Movie updatedMovie);

    }
}

