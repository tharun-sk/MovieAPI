﻿using Microsoft.AspNetCore.Mvc;
using MovieAPI.Models;
using MovieAPI.Repository;




[Route("api/[controller]")]
[ApiController]
public class MovieController : ControllerBase
{
    IMovieRepository _repository;

    public MovieController(IMovieRepository repository)
    {
        _repository = repository;
    }

    [HttpGet]
    public ActionResult<List<Movie>> GetAll() //actionresult is a parent class 
    {
        var result = _repository.GetAll();
        if (result == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(result);
        }
    }

    [HttpGet("{id}")]
    public ActionResult<Movie> Get(int id)
    {
        var result = _repository.GetById(id);

        if (result == null)
        {
            return NotFound("Id Not Found");
        }
        else
        {
            return Ok(result);
        }
    }

    [HttpPost]
    public ActionResult<Movie> Post(Movie newMovie)
    {
        if (newMovie == null)
        {
            return BadRequest("Invalid movie data.");
        }

        var createdMovie = _repository.Add(newMovie);

        return CreatedAtAction(nameof(Get), new { id = createdMovie.MovieId }, createdMovie);
    }

    [HttpPut("{id}")]
    public ActionResult<Movie> Put(int id, [FromBody] Movie updatedMovie)
    {
        if (updatedMovie == null || updatedMovie.MovieId != id)
        {
            return BadRequest("Invalid movie data or ID mismatch.");
        }

        var existingMovie = _repository.GetById(id);
        if (existingMovie == null)
        {
            return NotFound("Movie not found.");
        }

        _repository.Update(updatedMovie); // Call the repository method to update the movie.
        return Ok(updatedMovie); // Return the updated movie.
    }

    [HttpDelete("{id}")]
    public ActionResult Delete(int id)
    {
        int result = _repository.DeleteMovie(id);
        if (result > 0)
        {
            return NoContent();
        }
        return NotFound();
    }
    
}